#define CONFIG_CHRT 1
