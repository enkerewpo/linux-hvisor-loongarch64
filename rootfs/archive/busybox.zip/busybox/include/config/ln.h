#define CONFIG_LN 1
