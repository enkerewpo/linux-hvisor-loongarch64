#define CONFIG_SV_DEFAULT_SERVICE_DIR "/var/service"
