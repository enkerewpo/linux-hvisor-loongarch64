#define CONFIG_UDHCPC6_DEFAULT_SCRIPT "/usr/share/udhcpc/default6.script"
