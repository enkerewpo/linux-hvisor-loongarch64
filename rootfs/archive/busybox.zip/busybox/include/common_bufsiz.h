enum { COMMON_BUFSIZE = 1024 };
extern char bb_common_bufsiz1[];
#define setup_common_bufsiz() ((void)0)
