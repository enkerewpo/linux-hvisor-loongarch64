[This content has moved to the UAPI group website](https://uapi-group.org/specifications/specs/boot_loader_specification/)
